# Set the environment variable

base_info = '/data3/home/jqyang/high-throughput/script/construction/base-function/codes/Info/Element_Info'