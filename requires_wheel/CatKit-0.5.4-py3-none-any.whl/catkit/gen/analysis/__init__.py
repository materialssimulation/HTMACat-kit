# Copyright 2018
# (see accompanying license files for details).
from .classifier import Classifier

__all__ = ['Classifier']
